window.PORTFOLIO_DATA = {
  profile: {
    name: 'Zilan Zalilan',
    headline: 'Software Engineer Intern Candidate | Laravel & PHP Developer | D4 Teknik Informatika Politeknik Negeri Malang',
    headlineEn: 'Software Engineer Intern Candidate | Laravel & PHP Developer | Applied Informatics Engineering Student at State Polytechnic of Malang',
    email: 'zilanzalilan18@gmail.com',
    phone: '+62 896-3322-9848',
    github: 'https://github.com/Thesambala',
    linkedin: 'https://linkedin.com/zilanzalilan',
    website: 'assets/CV-PORTOFOLIO-Zilan.pdf',
    cv: 'assets/CV-Zilan.pdf',
    location: 'Surabaya/Malang, Indonesia',
    photo: 'assets/profile-zilan.jpg'
  },
  focus: [
    { icon: '★', title: 'Laravel Development', desc: 'Pengembangan aplikasi web berbasis Laravel dan PHP dengan struktur fitur yang rapi, mudah dirawat, dan siap dikembangkan.', descEn: 'Laravel and PHP web application development with clean, maintainable, and expandable feature structures.' },
    { icon: '✦', title: 'UI Design', desc: 'Perancangan User Interface menggunakan Figma untuk website internal/eksternal dengan navigasi intuitif dan layout informatif.', descEn: 'User Interface design with Figma for internal/external websites with intuitive navigation and informative layouts.' },
    { icon: '◈', title: 'Database & SQL', desc: 'Perancangan database SQL menggunakan MySQL dan SQL Server untuk mendukung sistem yang efisien dan scalable.', descEn: 'SQL database design using MySQL and SQL Server to support efficient and scalable systems.' },
    { icon: '▣', title: 'System Analysis', desc: 'Menganalisis kebutuhan, memecah masalah teknis, dan menyusun alur data agar solusi digital lebih terstruktur.', descEn: 'Analyzing requirements, breaking down technical problems, and designing structured data flows.' },
    { icon: '⬡', title: 'Digital Operations', desc: 'Terbiasa dengan transaksi, stok, layanan pelanggan, dan pekerjaan operasional yang membutuhkan akurasi serta ketahanan kerja.', descEn: 'Experienced in transactions, stock handling, customer service, and operations that require accuracy and resilience.' },
    { icon: '⌁', title: 'Communication & Leadership', desc: 'Menguatkan kerja tim, komunikasi, public speaking, dan kepemimpinan dalam project maupun aktivitas lapangan.', descEn: 'Strengthening teamwork, communication, public speaking, and leadership in projects and field activities.' }
  ],
  education: [
    {
      period: '2024 - Sekarang', periodEn: '2024 - Present',
      title: 'Politeknik Negeri Malang',
      subtitle: 'D4 - Teknik Informatika', subtitleEn: 'Bachelor of Applied Science - Informatics Engineering',
      desc: 'Sedang menempuh pendidikan D4 Teknik Informatika dengan fokus pada pengembangan sistem, database, dan solusi digital.',
      descEn: 'Currently studying Applied Informatics Engineering with a focus on system development, databases, and digital solutions.',
      tags: ['D4 Informatics', 'System Development', 'Database']
    },
    {
      period: '2022 - 2023', periodEn: '2022 - 2023',
      title: 'Politeknik Negeri Malang',
      subtitle: 'D2 - Web Development / Perangkat Piranti Lunak Situs', subtitleEn: 'D2 - Web Development',
      desc: 'Lulusan D2 dengan dasar pengembangan website, logika pemrograman, dan implementasi aplikasi berbasis web.',
      descEn: 'Graduated from D2 with foundations in website development, programming logic, and web application implementation.',
      tags: ['Web Development', 'PHP', 'SQL']
    },
    {
      period: 'SMKN 2 Malang', periodEn: 'Vocational School',
      title: 'Teknik Komputer dan Jaringan',
      subtitle: 'Foundation in Computer & Network Engineering', subtitleEn: 'Computer and Network Engineering Foundation',
      desc: 'Membangun dasar teknis di bidang komputer dan jaringan sebelum melanjutkan ke pengembangan perangkat lunak.',
      descEn: 'Built technical foundations in computers and networking before continuing into software development.',
      tags: ['Computer Network', 'Technical Foundation', 'BNSP']
    }
  ],
  projects: [
    {
      id: 'astraea', featured: true,
      title: 'ASTRAEA — Smart Traffic Dashboard',
      category: 'Dashboard & IoT',
      image: 'assets/project-astraea.webp',
      short: 'Dashboard monitoring lalu lintas real-time dengan visual kontrol, ringkasan jalur, status perangkat, dan data sensor.',
      shortEn: 'A real-time traffic monitoring dashboard with control visuals, lane summaries, device status, and sensor data.',
      long: 'ASTRAEA menampilkan pendekatan sistem dashboard untuk memvisualisasikan data lalu lintas, status sensor, dan kontrol lampu secara terstruktur. Tampilan ini cocok sebagai studi visual dashboard operasional dengan data real-time dan kontrol manual.',
      longEn: 'ASTRAEA presents a dashboard system approach to visualize traffic data, sensor status, and structured signal control. It is suitable as a visual case study for an operational real-time dashboard with manual control.',
      tech: ['Dashboard', 'Real-time UI', 'JavaScript', 'Data Visualization', 'IoT Concept', 'Responsive Layout'],
      problem: 'Sistem lalu lintas membutuhkan tampilan yang jelas untuk membaca status jalur, kepadatan, dan kontrol perangkat secara cepat.',
      problemEn: 'Traffic systems need a clear interface to read lane status, density, and device control quickly.',
      solution: 'Menyajikan UI dashboard dengan panel ringkasan, visual map, status jalur, dan kontrol manual yang mudah dipahami.',
      solutionEn: 'Presented a dashboard UI with summary cards, visual map, lane status, and understandable manual controls.',
      role: 'UI/dashboard contributor dan system interface designer.', roleEn: 'UI/dashboard contributor and system interface designer.',
      architecture: 'Sensor data concept → dashboard state → visual map → control panel → responsive monitoring interface.',
      challenges: 'Menjaga informasi real-time tetap mudah dibaca tanpa membuat dashboard terasa padat.',
      result: 'Dashboard terlihat profesional untuk monitoring, presentasi project, dan simulasi kontrol lalu lintas.',
      live: '#', github: 'https://github.com/Thesambala'
    },
    {
      id: 'lencana', featured: false,
      title: 'Lencana — Sistem Informasi Prestasi Mahasiswa',
      category: 'UI Design & Web System', image: 'assets/project-lencana.webp',
      short: 'Platform digital untuk mendokumentasikan dan mempublikasikan pencapaian akademik dan non-akademik mahasiswa.',
      shortEn: 'A digital platform to document and publish students’ academic and non-academic achievements.',
      long: 'Lencana adalah rancangan sistem informasi prestasi mahasiswa. Project ini diarahkan untuk membantu pendataan, publikasi, dan penelusuran prestasi mahasiswa melalui tampilan website yang informatif, sederhana, dan mudah digunakan.',
      longEn: 'Lencana is a student achievement information system design. The project supports data collection, publication, and exploration of student achievements through an informative, simple, and usable website interface.',
      tech: ['Figma', 'UI Design', 'Information Architecture', 'Web Design', 'HTML/CSS Concept'],
      problem: 'Prestasi mahasiswa perlu didokumentasikan dan dipublikasikan secara lebih rapi agar mudah ditemukan oleh mahasiswa maupun staf.',
      problemEn: 'Student achievements need to be documented and published more neatly so students and staff can find them easily.',
      solution: 'Merancang UI website dengan navigasi Beranda, Telusuri Prestasi, Tentang Kami, Kontak, dan Login.',
      solutionEn: 'Designed a website UI with Home, Achievement Exploration, About, Contact, and Login navigation.',
      role: 'UI designer: wireframe, mockup visual, dan perancangan pengalaman pengguna.',
      roleEn: 'UI designer: wireframes, visual mockups, and user experience planning.',
      architecture: 'User landing page → achievement exploration → content detail → login access → data management flow.',
      challenges: 'Membuat tampilan yang formal untuk institusi namun tetap mudah dipahami pengguna.',
      result: 'Desain landing page dan flow utama yang siap dipresentasikan sebagai konsep sistem informasi prestasi.',
      live: '#', github: 'https://github.com/Thesambala'
    },
    {
      id: 'salindia', featured: false,
      title: 'Salindia — Sistem Manajemen Sarana dan Prasarana',
      category: 'Management System Prototype', image: 'assets/project-salindia.webp',
      short: 'Prototipe sistem manajemen sarana dan prasarana untuk pendataan, peminjaman, dan pemeliharaan aset secara terpusat.',
      shortEn: 'A facilities and infrastructure management prototype for centralized asset data, borrowing, and maintenance.',
      long: 'Salindia dikembangkan sebagai prototipe sistem manajemen sarana dan prasarana. Tujuannya memfasilitasi pendataan aset, peminjaman, pemeliharaan, serta meningkatkan efisiensi operasional dan akuntabilitas inventaris lembaga.',
      longEn: 'Salindia was developed as a facilities and infrastructure management prototype. It supports asset data management, borrowing, maintenance, and improves operational efficiency and inventory accountability.',
      tech: ['System Prototype', 'UI Design', 'Asset Management', 'Database Concept', 'Laravel-ready'],
      problem: 'Pendataan dan pemeliharaan aset sering tersebar sehingga proses peminjaman dan kontrol inventaris kurang efisien.',
      problemEn: 'Asset data and maintenance are often scattered, making borrowing and inventory control less efficient.',
      solution: 'Membuat konsep sistem terpusat untuk mencatat aset, memproses peminjaman, dan memantau pemeliharaan.',
      solutionEn: 'Created a centralized system concept to record assets, process borrowing, and monitor maintenance.',
      role: 'System planner dan prototype designer untuk alur fitur serta tampilan awal.',
      roleEn: 'System planner and prototype designer for feature flow and initial interface.',
      architecture: 'Asset database → borrowing workflow → maintenance record → admin monitoring.',
      challenges: 'Menyusun flow yang tetap sederhana meskipun sistem memiliki banyak status aset.',
      result: 'Prototype sistem manajemen aset yang siap dikembangkan menjadi aplikasi web berbasis database.',
      live: '#', github: 'https://github.com/Thesambala'
    }
  ],
  skills: {
    'Frontend & UI': ['HTML', 'CSS', 'JavaScript', 'Figma', 'Canva', 'Responsive Design'],
    'Backend': ['Laravel', 'PHP', 'Java', 'Python', 'REST API Concept'],
    'Database': ['MySQL', 'SQL Server', 'Database Design', 'Google Sheet'],
    'Tools': ['Microsoft Word', 'Excel', 'PowerPoint', 'CapCut', 'GitHub'],
    'Professional Skills': ['Leadership', 'Teamwork', 'Critical Thinking', 'Analytical Thinking', 'Communication', 'Problem Solving', 'Time Management'],
    'Career Focus': ['Software Engineer Intern', 'Web Development', 'UI Implementation', 'System Analysis']
  },
  experiences: [
    { period: '2024', title: 'Saksi Pemilu', desc: 'Mengawal proses pemungutan suara, validasi dokumen, dan rekapitulasi suara dengan ketelitian tinggi.', descEn: 'Supervised voting processes, document validation, and vote recap with high attention to detail.', tags: ['Accuracy', 'Integrity', 'Documentation'] },
    { period: '2022 - 2023', title: 'Internship — Olahkarsa', desc: 'Merancang UI menggunakan Figma untuk project website internal/eksternal dan berkolaborasi dengan tim developer.', descEn: 'Designed UI using Figma for internal/external website projects and collaborated with developer teams.', tags: ['Figma', 'UI Design', 'Collaboration'] },
    { period: '2023', title: 'Barista — E29', desc: 'Menangani customer service, transaksi kasir, stok bahan, dan operasional harian pada jam sibuk.', descEn: 'Handled customer service, cashier transactions, stock management, and daily operations during busy hours.', tags: ['Customer Service', 'Operations', 'Multitasking'] },
    { period: 'Project 1', title: 'Lencana', desc: 'Platform digital untuk dokumentasi dan publikasi pencapaian akademik maupun non-akademik mahasiswa.', descEn: 'A digital platform for documenting and publishing students’ academic and non-academic achievements.', tags: ['UI Design', 'Figma', 'Student Achievement'] },
    { period: 'Project 2', title: 'Salindia', desc: 'Prototipe sistem manajemen sarana dan prasarana untuk pendataan, peminjaman, dan pemeliharaan aset.', descEn: 'A facilities and infrastructure management prototype for asset data, borrowing, and maintenance.', tags: ['Prototype', 'Asset Management', 'Database'] }
  ],
  blog: [
    { title: 'Catatan Laravel: Struktur Fitur yang Rapi', titleEn: 'Laravel Notes: Clean Feature Structure', category: 'Laravel', date: '2026-07-03', excerpt: 'Catatan singkat tentang cara menyusun controller, route, model, dan view agar aplikasi web mudah dikembangkan.', excerptEn: 'Notes on structuring controllers, routes, models, and views to make web apps easier to expand.' },
    { title: 'Mendesain UI yang Bisa Diimplementasikan Developer', titleEn: 'Designing UI Developers Can Implement', category: 'UI Design', date: '2026-07-03', excerpt: 'Prinsip desain Figma yang realistis: konsistensi komponen, jarak, navigasi, dan state halaman.', excerptEn: 'Realistic Figma design principles: component consistency, spacing, navigation, and page states.' },
    { title: 'Database SQL untuk Sistem Manajemen Aset', titleEn: 'SQL Database for Asset Management Systems', category: 'Database', date: '2026-07-03', excerpt: 'Ide entity utama untuk sistem aset: barang, peminjam, transaksi, pemeliharaan, status, dan laporan.', excerptEn: 'Core entities for asset systems: items, borrowers, transactions, maintenance, status, and reports.' }
  ],

  certificates: [
    { id: 'bnsp-web-pratama', featured: true, title: 'BNSP Web Developer Pratama', issuer: 'BNSP / Politeknik Negeri Malang', year: '2023', category: 'Professional Certification', fileType: 'PDF', file: 'assets/certificates/files/bnsp-web-pratama.pdf', thumbnail: 'assets/certificates/thumbs/bnsp-web-pratama.webp', desc: 'Dummy proof untuk sertifikat kompetensi Pengembang Web Pratama. Nanti file ini bisa diganti dengan sertifikat asli Zilan.', descEn: 'Dummy proof for Web Developer Pratama competency certification. This can be replaced with Zilan’s real certificate file later.' },
    { id: 'bnsp-network-technician', featured: true, title: 'KKNI Level II Computer Network Technician', issuer: 'BNSP / SMKN 2 Malang', year: '2022', category: 'Professional Certification', fileType: 'PDF', file: 'assets/certificates/files/bnsp-network-technician.pdf', thumbnail: 'assets/certificates/thumbs/bnsp-network-technician.webp', desc: 'Dummy proof untuk sertifikasi kompetensi bidang komputer dan jaringan. Nanti diganti dengan file asli.', descEn: 'Dummy proof for computer and network competency certification. Replace with the original file later.' },
    { id: 'samsung-tech-institute', featured: true, title: 'Samsung Tech Institute Technician', issuer: 'Samsung Tech Institute', year: '2019–2022', category: 'Professional Certification', fileType: 'PDF', file: 'assets/certificates/files/samsung-tech-institute.pdf', thumbnail: 'assets/certificates/thumbs/samsung-tech-institute.webp', desc: 'Dummy proof untuk program Samsung Tech Institute dengan kompetensi teknisi perangkat.', descEn: 'Dummy proof for Samsung Tech Institute technician program.' },
    { id: 'olahkarsa-ui-internship', featured: false, title: 'UI Design Internship Contribution', issuer: 'Olahkarsa', year: '2022–2023', category: 'Internship & Work', fileType: 'PDF', file: 'assets/certificates/files/olahkarsa-ui-internship.pdf', thumbnail: 'assets/certificates/thumbs/olahkarsa-ui-internship.webp', desc: 'Dummy proof untuk pengalaman internship UI design di Olahkarsa.', descEn: 'Dummy proof for UI design internship experience at Olahkarsa.' },
    { id: 'laravel-php-development', featured: false, title: 'Laravel & PHP Web Development', issuer: 'Portfolio Evidence', year: '2026', category: 'Technical Skills', fileType: 'PDF', file: 'assets/certificates/files/laravel-php-development.pdf', thumbnail: 'assets/certificates/thumbs/laravel-php-development.webp', desc: 'Dummy credential untuk menunjukkan fokus pengembangan web Laravel dan PHP.', descEn: 'Dummy credential showing Laravel and PHP web development focus.' },
    { id: 'sql-system-analysis', featured: false, title: 'SQL Database & System Analysis', issuer: 'Portfolio Evidence', year: '2026', category: 'Technical Skills', fileType: 'PDF', file: 'assets/certificates/files/sql-system-analysis.pdf', thumbnail: 'assets/certificates/thumbs/sql-system-analysis.webp', desc: 'Dummy credential untuk database SQL, analisis sistem, dan pengelolaan data.', descEn: 'Dummy credential for SQL databases, system analysis, and data management.' }
  ],
  messages: [],
  settings: {
    siteTitle: 'Zilan Zalilan Portfolio',
    seoTitle: 'Zilan Zalilan — Software Engineer Portfolio',
    seoDescription: 'Portfolio project Laravel, UI design, database, smart dashboard, dan sistem manajemen digital.',
    defaultLanguage: 'id', maintenance: false, themeColor: 'professional-blue-slate'
  }
};

window.I18N = {
  id: {
    'nav.home': 'Home', 'nav.about': 'About', 'nav.projects': 'Projects', 'nav.stack': 'Stack', 'nav.certificates': 'Certificates', 'nav.journey': 'Journey', 'nav.blog': 'Blog', 'nav.contact': 'Contact', 'nav.cv': 'Download CV',
    'hero.kicker': 'Polinema Informatics • Laravel Track', 'hero.line1': 'Design', 'hero.line2': 'Build', 'hero.line3': 'Lead', 'hero.role': 'Software Engineer Intern Candidate | Laravel & PHP Developer | D4 Teknik Informatika Politeknik Negeri Malang', 'hero.desc': 'Saya membangun sistem web, UI, database, dan solusi digital yang efisien, scalable, serta siap dipresentasikan secara profesional.', 'hero.projects': 'Explore Projects', 'hero.contact': 'Contact Me',
    'stats.projects': 'Major Projects', 'about.title': 'Message from Zilan', 'about.body': 'Saya Zilan Zalilan, mahasiswa D4 Teknik Informatika Politeknik Negeri Malang dengan latar belakang D2 Web Development. Fokus saya ada pada pengembangan aplikasi web, rancangan UI, database SQL, dan implementasi solusi digital yang efisien serta scalable.', 'about.quote': '“Build clean systems, solve clearly, and deliver with precision.”',
    'focus.desc': 'Bidang yang saya gunakan untuk mengubah project kuliah, pengalaman kerja, dan eksplorasi pribadi menjadi portfolio yang siap dinilai recruiter maupun client.', 'projects.title': 'Featured Projects', 'projects.desc': 'Project disusun seperti project archive: visual kuat, problem-solution jelas, dan detail case study siap dibuka.', 'hall.title': 'Interfaces that prove the build.', 'hall.desc': 'Setiap gambar dipakai sebagai bukti visual: dashboard real-time, sistem prestasi mahasiswa, dan prototype manajemen sarana prasarana.', 'stack.title': 'Technology Stack', 'stack.desc': 'Dikelompokkan agar recruiter/client langsung memahami skill teknis, tools, dan kekuatan profesional Zilan.', 'journey.desc': 'Perjalanan dari pendidikan web development, project kampus, internship UI, sampai kesiapan menjadi Software Engineer Intern.', 'blog.title': 'Blog & Learning Notes', 'blog.desc': 'Area untuk catatan belajar Laravel, UI design, database, dan dokumentasi problem solving.', 'certificates.title': 'Certificates & Credentials', 'certificates.desc': 'Sertifikat dibuat sebagai credential library: featured certificates tetap terlihat di homepage, sementara seluruh bukti PDF bisa dicari, difilter, dan dibuka.', 'contact.title': 'Let’s build a clean digital system.', 'contact.desc': 'Hubungi saya untuk kolaborasi project, internship, pengembangan website, UI, atau sistem berbasis database.',
    'form.name': 'Nama', 'form.subject': 'Subjek', 'form.message': 'Pesan', 'form.send': 'Kirim Pesan'
  },
  en: {
    'nav.home': 'Home', 'nav.about': 'About', 'nav.projects': 'Projects', 'nav.stack': 'Stack', 'nav.certificates': 'Certificates', 'nav.journey': 'Journey', 'nav.blog': 'Blog', 'nav.contact': 'Contact', 'nav.cv': 'Download CV',
    'hero.kicker': 'Polinema Informatics • Laravel Track', 'hero.line1': 'Design', 'hero.line2': 'Build', 'hero.line3': 'Lead', 'hero.role': 'Software Engineer Intern Candidate | Laravel & PHP Developer | Applied Informatics Engineering Student at State Polytechnic of Malang', 'hero.desc': 'I build web systems, UI, databases, and digital solutions that are efficient, scalable, and presentation-ready.', 'hero.projects': 'Explore Projects', 'hero.contact': 'Contact Me',
    'stats.projects': 'Major Projects', 'about.title': 'Message from Zilan', 'about.body': 'I am Zilan Zalilan, an Applied Informatics Engineering student at State Polytechnic of Malang with a D2 Web Development background. My focus is web application development, UI design, SQL databases, and efficient scalable digital solutions.', 'about.quote': '“Build clean systems, solve clearly, and deliver with precision.”',
    'focus.desc': 'Fields I use to turn college projects, work experience, and personal exploration into a portfolio ready for recruiters and clients.', 'projects.title': 'Featured Projects', 'projects.desc': 'Projects are organized like a project archive: strong visuals, clear problem-solution, and case-study-ready details.', 'hall.title': 'Interfaces that prove the build.', 'hall.desc': 'Each image works as visual proof: real-time dashboard, student achievement system, and facilities management prototype.', 'stack.title': 'Technology Stack', 'stack.desc': 'Grouped so recruiters/clients can quickly understand Zilan’s technical skills, tools, and professional strengths.', 'journey.desc': 'A path from web development education, campus projects, and UI internship to readiness as a Software Engineer Intern.', 'blog.title': 'Blog & Learning Notes', 'blog.desc': 'A place for Laravel, UI design, database, and problem-solving notes.', 'certificates.title': 'Certificates & Credentials', 'certificates.desc': 'Certificates are arranged as a credential library: featured certificates stay visible on the homepage while all PDF proofs remain searchable, filterable, and accessible.', 'contact.title': 'Let’s build a clean digital system.', 'contact.desc': 'Contact me for project collaboration, internship, website development, UI, or database-based systems.',
    'form.name': 'Name', 'form.subject': 'Subject', 'form.message': 'Message', 'form.send': 'Send Message'
  }
};
